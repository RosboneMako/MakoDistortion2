Mako Distortion 2

JUCE VST3 guitar processor.
Tested on Windows only.
Written in Visual C++ 2022.
Version: 3.00
February 5, 2025
_________________________________________

Mako Distortion 2 (MD2) is a Virtual Studio Technology (VST) file that can be used
in audio applications to create musical effects.

This ZIP does not include/require a setup program. The VST or EXE files are stand alone files you 
place where needed.

These programs were built using Visual Studio C++ 2022. If problems running the apps occur
the Microsoft C++ runtime files for 2022 may be needed. 


HOW TO USE THE VST3 FILE
Digital Audio Workstations (DAW) use VST files for effects and other things. DAW's
will look for VST files when they load. The VST files must be in specific directory
locations on your computer. The directories the DAW uses are setup in the DAW settings.

To use MD2, copy it into one of the directories your DAW searches when starting.


STAND ALONE
JUCE also creates a stand alone executable file during builds. This file can be run
from any location and does not rely on a DAW. This is useful for building MD2 presets.
Just start MD2 and stat working. 

The stand alone program needs to know which audio device inputs/outputs to use. These
are setup from the OPTIONS button on the dialog box title bar. 

The EXE is also useful for doing things like streaming and live operations. You can run
multiple instances of the EXE: one for guitar, one for bass, one for vocals, etc.


AUDIO DRIVERS
The easy way to use MD2 is in your DAW. Because the DAW will try to use the best possible
audio driver for your system.

When using the EXE file you have the option to setup which driver works. 
In the OPTIONS menu you select the driver in the AUDIO DEVICE TYPE.
Typically you will see Windows Audio, ASIO, etc. Test each one and see which driver has
the lowest latency (LAG). ASIO is usually best but depends on the manufacturer implementation.

Many people use ASIO4ALL generic drivers to try and get the best latency. It is dependent
on your audio device.


MAKO DISTORTION DATABASE
VSTs do not like to save string variables. This VST uses a database to store the locations of
external files. Amplifiers and Speaker IR each have an editable database managed in the VST.
To use any external files, this database needs to be edited. 

SAMPLE IMPULSE RESPONSE (IR) FILES
A few IRs are added to this zip as examples of the IR format required for MD2. MD2 is designed
around a 48kHz sample rate and best results come from 48kHz IR files. MD2 has 19 built in IRs
that can be adjusted to meet most needs, so external IRs are not required to operate. 

SAMPLE AMPLIFIER INPUT IR FILES
There are many included Amp IR files. These files are loaded by selecting them from the Amp
drop down list. Note: Files must be setup in the amp database before they appear in the amp list.
Adjust the Boom and Crisp values for simple EQing of the IR.

WAVEFORM AND WAVESAMPLE FILES
A few demo files have been included for use in the modulation synth effects.
Waveform files are used on the MoMo synth.
Samples files are used in the Sammy and Harpy synths.

